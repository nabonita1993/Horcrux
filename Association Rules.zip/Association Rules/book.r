Books<-book
View(Books)
summary(Books)


# Association Rules 
install.packages("arulesViz")
library(arules)
library(arulesViz)

# Item Frequecy plot
windows()

# Applying apriori algorithm to get relevant rules
rules1 <- apriori(as.matrix(Books),parameter = list(support=0.02,confidence=0.5,minlen=2))
rules2 <- apriori(as.matrix(Books),parameter = list(support=0.01,confidence=0.2,minlen=3))
rules3 <- apriori(as.matrix(Books),parameter = list(support=0.02,confidence=0.1,minlen=4))
rules4 <- apriori(as.matrix(Books),parameter = list(support=0.01,confidence=0.1,minlen=2))

options(max.print=999999)

inspect(rules)
plot(rules)

# Sorting rules by confidence 
rules_conf <- sort(rules,by="confidence")
inspect(rules_conf)
plot(rules_conf)

# Sorint rules by lift ratio
rules_lift <- sort(rules,by="lift")
inspect(rules_lift)
plot(rules_lift)

# Visualizing rules in scatter plot

plot(rules,method = "graph")
