train_data<-Salary_Data[1:20, ]
test_data<-Salary_Data[21:30, ]
ye<-Salary_Data$YearsExperience
s<-Salary_Data$Salary
plot(s,ye)
plot(ye,s)
cor(s,ye)
regModel<-lm(s~ye, data = train_data)
summary(regModel)
ypred<-predict(regModel,data=test_data)
summary(ypred)

plot(ypred)
View(train_data)
View(test_data)
