View(delivery_time)
dt<-delivery_time$Delivery.Time
st<-delivery_time$Sorting.Time
plot(dt,st)
summary(delivery_time)
cor(dt,st)
model<-lm(dt~st)
model
summary(model)
y_predict<-predict(model,data=delivery_time)
y_predict


library(caTools)
library(caret)
inTraininglocal<-createDataPartition(emp_data$Churn_out_rate,p= .70,list=F)
training<-emp_data [inTraininglocal,]
testing<-emp_data[-inTraininglocal,]
View(training)



View(emp_data)
train_data<-emp_data[1:7, ]
test_data<-emp_data[8:10, ]
sh<-emp_data$Salary_hike
chor<-emp_data$Churn_out_rate
plot(chor,sh)
summary(emp_data)
cor(chor,sh)
RegModel<-lm(chor~sh, data=train_data)
summary(RegModel)
ypredict<-predict(RegModel,data = test_data)
summary(ypredict)
ypredict
plot(ypredict)
