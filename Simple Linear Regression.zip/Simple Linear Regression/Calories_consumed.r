View(calories_consumed)
plot(calories_consumed$Calories.Consumed, calories_consumed$Weight.gained..grams.)
plot(calories_consumed$Weight.gained..grams., calories_consumed$Calories.Consumed)
summary(calories_consumed)
cor(calories_consumed$Weight.gained..grams., calories_consumed$Calories.Consumed)
reg<-lm(calories_consumed$Weight.gained..grams.~calories_consumed$Calories.Consumed)
reg
summary(reg)


View(calories_consumed)
cc<-calories_consumed$Calories.Consumed
wtg<-calories_consumed$Weight.gained..grams.
plot(cc,wtg)
summary(calories_consumed)
cor(wtg,cc)
regModel<-lm(wtg~cc)
regModel
summary(regModel)
y_pred<-predict(regModel,data=calories_consumed)
y_pred
