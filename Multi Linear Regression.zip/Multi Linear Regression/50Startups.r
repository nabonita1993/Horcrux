## 50_startups

data_set<-`50_Startups`
summary(data_set)


##Find the correlation b/n Output (profit) & (R&D Spend,Administration,Marketing Spend, State
pairs(data_set)

## Corelation
cor(data_set)

library(plyr)

data_set$State<-revalue(data_set$State,c("New York"="0", "California"="1", "Florida"="2"))
attach(data_set)
startups <- cbind(RD_Spend=R.D.Spend,Administration,Marketing_Spend=Marketing.Spend,State,Profit)
startups<-as.data.frame(startups)
summary(startups)
View(startups)

## Corelation
cor(startups)

# The Linear Model of interest
LinearModel.Startups <- lm(startups$Profit~., data = startups)
summary(LinearModel.Startups)  ##  Adjusted R-squared:  0.9464

# Multicollinearity check
# Model based on only Administration
model.admn<-lm(startups$Profit~startups$Administration, data = startups)
summary(model.admn)  ##Adjusted R-squared:  0.02029 

# Model based on only Marketing spends
model.MS<-lm(startups$Profit~startups$Marketing_Spend,data=startups)
summary(model.MS) ## Adjusted R-squared:   0.55

# Model based on Administration and Marketing.Spend
model.adm_ms<-lm(startups$Profit~startups$Administration+startups$Marketing_Spend,data=startups)
summary(model.adm_ms)  ##Adjusted R-squared:  0.5931

# Applying VIF function on model built on all inputs
library(car)
vif(LinearModel.Startups) # Original model
vif(model.adm_ms)

##Logarithmic model
LogModel.Startups <- lm(Profit~startups$RD_Spend+log(Administration)+startups$Marketing_Spend)
summary(LogModel.Startups)  ##Adjusted R-squared:  0.9474
confint(LogModel.Startups,level=0.95)
predict(LogModel.Startups,interval="predict")

##Exponential model
ExpModel.Startups <- lm(log(Profit)~startups$RD_Spend+Administration+startups$Marketing_Spend, data=startups)
summary(ExpModel.Startups)  ##Adjusted R-squared:  0.7462


##Quad model
QuadModel.Startups <- lm(Profit~RD_Spend+I(RD_Spend^2)+Administration+I(Administration^2)
                          +Marketing_Spend+I(Marketing_Spend^2)+State+I(State^2),data=startups[-c(49,50),])

summary(QuadModel.Startups)    ##Adjusted R square is 0.9567
confint(QuadModel.Startups,level=0.95)
predict(QuadModel.Startups,interval="predict") 


##Poly model
PolyModel.Startups <- lm(Profit~RD_Spend+I(RD_Spend^2)+I(RD_Spend^3)+Administration+I(Administration^2)+I(Administration^3)
                         +Marketing_Spend+I(Marketing_Spend^2)+I(Marketing_Spend^3)+State+I(State^2)+I(State^3),data=startups[-c(49,50),])

summary(PolyModel.Startups) ## Adjusted R-squared:  0.9569
confint(PolyModel.Startups,level=0.95)
predict(PolyModel.Startups,interval="predict")


model_RSquaredvalues <- list(model=NULL,R_squared=NULL)
model_RSquaredvalues[["model"]] <- c("LinearModel.Startups","LogModel.Startups","ExpModel.Startups","QuadModel.Startups","PolyModel.Startups")
model_RSquaredvalues[["R_squared"]] <- c(0.9464,0.9474 ,0.7462,0.9567,0.9569)
Final <- cbind(model_RSquaredvalues[["model"]],model_RSquaredvalues[["R_squared"]])
Final


# Model.reg gives the best Adjusted R-Squared value
pred_final <- predict(PolyModel.Startups)
pred_final
summary(pred_final)

hist(residuals(PolyModel.Startups))
plot(residuals(PolyModel.Startups))

plot(pred_final)


library(MASS)
stepAIC(PolyModel.Startups)
